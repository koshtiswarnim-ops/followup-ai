
import { prisma } from "@/lib/prisma";
import { LeadStatus, LeadSource, ActivityType } from "@prisma/client";

export interface CreateLeadInput {
  businessId: string; userId: string; name: string; phone?: string; email?: string;
  course?: string; source?: LeadSource; notes?: string; assignedTo?: string;
}

export interface UpdateLeadInput {
  name?: string; phone?: string; email?: string; course?: string;
  source?: LeadSource; status?: LeadStatus; notes?: string; assignedTo?: string;
}

export async function createLead(input: CreateLeadInput) {
  const lead = await prisma.lead.create({
    data: {
      businessId: input.businessId, name: input.name, phone: input.phone,
      email: input.email, course: input.course, source: input.source || "OTHER",
      notes: input.notes, assignedTo: input.assignedTo,
    },
    include: { assignedUser: { select: { id: true, name: true, email: true } } },
  });

  await prisma.activity.create({
    data: {
      businessId: input.businessId, leadId: lead.id, userId: input.userId,
      type: ActivityType.LEAD_CREATED, description: `Lead created for ${input.name}`,
      metadata: { source: input.source, course: input.course },
    },
  });

  // Increment subscription usage
  await prisma.subscription.updateMany({
    where: { businessId: input.businessId },
    data: { leadsUsedThisMonth: { increment: 1 } },
  });

  return lead;
}

export async function updateLead(id: string, businessId: string, userId: string, input: UpdateLeadInput) {
  const old = await prisma.lead.findFirst({ where: { id, businessId } });
  if (!old) throw new Error("Lead not found");

  const lead = await prisma.lead.update({
    where: { id },
    data: { ...input, updatedAt: new Date(), lastContact: input.status === "CONTACTED" ? new Date() : undefined },
    include: { assignedUser: { select: { id: true, name: true, email: true } } },
  });

  const changes: string[] = [];
  if (input.status && input.status !== old.status) changes.push(`Status: ${old.status} → ${input.status}`);
  if (input.assignedTo !== undefined && input.assignedTo !== old.assignedTo) changes.push("Counsellor reassigned");

  if (changes.length > 0) {
    await prisma.activity.create({
      data: {
        businessId, leadId: id, userId, type: ActivityType.LEAD_UPDATED,
        description: changes.join(", "), metadata: { changes },
      },
    });
  }
  return lead;
}

export async function getLeads(businessId: string, options: { page?: number; limit?: number; status?: string; source?: string; search?: string; assignedTo?: string }) {
  const { page = 1, limit = 20, status, source, search, assignedTo } = options;
  const skip = (page - 1) * limit;

  const where: any = { businessId };
  if (status) where.status = status;
  if (source) where.source = source;
  if (assignedTo) where.assignedTo = assignedTo;
  if (search) where.OR = [{ name: { contains: search, mode: "insensitive" } }, { phone: { contains: search } }, { email: { contains: search, mode: "insensitive" } }];

  const [leads, total] = await Promise.all([
    prisma.lead.findMany({
      where, skip, take: limit, orderBy: { createdAt: "desc" },
      include: {
        assignedUser: { select: { id: true, name: true, email: true } },
        followUps: { where: { status: "PENDING" }, orderBy: { scheduledAt: "asc" }, take: 1 },
      },
    }),
    prisma.lead.count({ where }),
  ]);

  return { leads, total, pages: Math.ceil(total / limit), page };
}

export async function getLeadById(id: string, businessId: string) {
  return prisma.lead.findFirst({
    where: { id, businessId },
    include: {
      assignedUser: { select: { id: true, name: true, email: true } },
      followUps: { orderBy: { scheduledAt: "desc" }, include: { assignedUser: { select: { id: true, name: true } } } },
      activities: { orderBy: { createdAt: "desc" }, take: 50, include: { user: { select: { id: true, name: true } } } },
      aiGenerations: { orderBy: { createdAt: "desc" }, take: 10 },
    },
  });
}

export async function deleteLead(id: string, businessId: string, userId: string) {
  const lead = await prisma.lead.findFirst({ where: { id, businessId } });
  if (!lead) throw new Error("Lead not found");
  await prisma.lead.delete({ where: { id } });
  await prisma.activity.create({
    data: { businessId, userId, type: ActivityType.LEAD_DELETED, description: `Lead deleted: ${lead.name}` },
  });
}
