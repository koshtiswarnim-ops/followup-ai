
import { prisma } from "@/lib/prisma";
import { FollowUpStatus, FollowUpChannel, ActivityType } from "@prisma/client";
import { sendWhatsAppMessage } from "@/lib/whatsapp";
import { sendFollowUpReminderEmail } from "@/lib/email";

export interface CreateFollowUpInput {
  businessId: string; leadId: string; userId: string; scheduledAt: Date;
  message?: string; channel?: FollowUpChannel; assignedTo?: string; notes?: string;
}

export async function createFollowUp(input: CreateFollowUpInput) {
  const fu = await prisma.followUp.create({
    data: {
      businessId: input.businessId, leadId: input.leadId, assignedTo: input.assignedTo,
      scheduledAt: input.scheduledAt, message: input.message,
      channel: input.channel || "MANUAL", status: "PENDING", notes: input.notes,
    },
    include: { lead: true, assignedUser: { select: { id: true, name: true, email: true } } },
  });

  await prisma.activity.create({
    data: {
      businessId: input.businessId, leadId: input.leadId, userId: input.userId,
      type: ActivityType.FOLLOW_UP_CREATED,
      description: `Follow-up scheduled for ${fu.scheduledAt.toLocaleDateString("en-IN")}`,
    },
  });

  await prisma.lead.update({ where: { id: input.leadId }, data: { status: "FOLLOW_UP", updatedAt: new Date() } });

  return fu;
}

export async function createFollowUpSequence(businessId: string, leadId: string, userId: string, intervals: number[] = [1, 3, 7, 14]) {
  const now = new Date();
  const followUps = [];
  for (const days of intervals) {
    const scheduledAt = new Date(now);
    scheduledAt.setDate(scheduledAt.getDate() + days);
    const fu = await createFollowUp({ businessId, leadId, userId, scheduledAt, channel: "WHATSAPP" });
    followUps.push(fu);
  }
  return followUps;
}

export async function processOverdueFollowUps() {
  const now = new Date();
  const overdue = await prisma.followUp.findMany({
    where: { status: "PENDING", scheduledAt: { lte: now } },
    include: { lead: true, assignedUser: { select: { email: true, name: true } }, business: true },
    take: 100,
  });

  console.log(`Processing ${overdue.length} overdue follow-ups`);

  for (const fu of overdue) {
    try {
      if (fu.channel === "WHATSAPP" && fu.message && fu.lead.phone) {
        const result = await sendWhatsAppMessage({ to: fu.lead.phone, message: fu.message });
        await prisma.followUp.update({
          where: { id: fu.id },
          data: { status: result.success ? "SENT" : "FAILED", sentAt: result.success ? new Date() : undefined },
        });
      } else if (fu.channel === "EMAIL" && fu.assignedUser?.email) {
        await sendFollowUpReminderEmail(fu.assignedUser.email, fu.assignedUser.name, fu.lead.name, fu.scheduledAt);
        await prisma.followUp.update({ where: { id: fu.id }, data: { status: "SENT", sentAt: new Date() } });
      } else {
        // Create notification for manual follow-ups
        if (fu.assignedTo) {
          await prisma.notification.create({
            data: {
              businessId: fu.businessId, userId: fu.assignedTo,
              type: "FOLLOW_UP_DUE",
              title: `Follow-up due: ${fu.lead.name}`,
              message: `Your follow-up with ${fu.lead.name} is due now.`,
            },
          });
        }
      }
    } catch (err) {
      console.error(`Failed to process follow-up ${fu.id}:`, err);
    }
  }

  return { processed: overdue.length };
}

export async function completeFollowUp(id: string, businessId: string, userId: string) {
  const fu = await prisma.followUp.findFirst({ where: { id, businessId } });
  if (!fu) throw new Error("Follow-up not found");
  await prisma.followUp.update({ where: { id }, data: { status: "COMPLETED", sentAt: new Date() } });
  await prisma.activity.create({
    data: {
      businessId, leadId: fu.leadId, userId,
      type: ActivityType.FOLLOW_UP_COMPLETED, description: "Follow-up marked as completed",
    },
  });
  return fu;
}
