
"use client";
import { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import { LayoutDashboard, Users, Zap, Brain, FileText, BarChart3, UserCog, Plug, CreditCard, Settings, Menu, X, Building2, ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";

const NAV = [
  { href: "/dashboard", icon: LayoutDashboard, label: "Dashboard" },
  { href: "/dashboard/leads", icon: Users, label: "Leads" },
  { href: "/dashboard/follow-ups", icon: Zap, label: "Follow-ups" },
  { href: "/dashboard/ai-messages", icon: Brain, label: "AI Messages" },
  { href: "/dashboard/templates", icon: FileText, label: "Templates" },
  { href: "/dashboard/analytics", icon: BarChart3, label: "Analytics" },
  { href: "/dashboard/team", icon: UserCog, label: "Team" },
  { href: "/dashboard/integrations", icon: Plug, label: "Integrations" },
  { href: "/dashboard/billing", icon: CreditCard, label: "Billing" },
  { href: "/dashboard/settings", icon: Settings, label: "Settings" },
];

export default function DashboardSidebar({ business, userRole }: { business: any; userRole: string }) {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);

  const NavItems = () => (
    <nav className="flex-1 px-3 py-4 space-y-0.5">
      {NAV.map(item => {
        const active = pathname === item.href || (item.href !== "/dashboard" && pathname.startsWith(item.href));
        return (
          <Link key={item.href} href={item.href} onClick={() => setOpen(false)}
            className={cn("flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors",
              active ? "bg-blue-50 text-blue-700" : "text-gray-600 hover:bg-gray-100 hover:text-gray-900")}>
            <item.icon className={cn("w-4 h-4 flex-shrink-0", active ? "text-blue-600" : "text-gray-400")} />
            {item.label}
            {active && <ChevronRight className="w-3 h-3 ml-auto text-blue-400" />}
          </Link>
        );
      })}
    </nav>
  );

  return (
    <>
      {/* Mobile toggle */}
      <button onClick={() => setOpen(true)} className="lg:hidden fixed top-4 left-4 z-40 p-2 bg-white rounded-lg shadow-md border">
        <Menu className="w-5 h-5" />
      </button>

      {/* Mobile sidebar */}
      <AnimatePresence>
        {open && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="lg:hidden fixed inset-0 z-50 flex">
            <div className="bg-black/40 flex-1" onClick={() => setOpen(false)} />
            <motion.aside initial={{ x: -280 }} animate={{ x: 0 }} exit={{ x: -280 }} transition={{ type: "spring", damping: 30, stiffness: 300 }}
              className="w-64 bg-white h-full flex flex-col shadow-xl">
              <div className="flex items-center justify-between p-4 border-b">
                <span className="font-bold text-blue-700">FollowUp AI</span>
                <button onClick={() => setOpen(false)}><X className="w-5 h-5 text-gray-500" /></button>
              </div>
              <div className="px-3 py-3 border-b">
                <div className="flex items-center gap-2 px-3">
                  <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center"><Building2 className="w-4 h-4 text-blue-600" /></div>
                  <div><div className="text-sm font-semibold text-gray-900 truncate">{business.name}</div><div className="text-xs text-gray-400 capitalize">{userRole.toLowerCase()}</div></div>
                </div>
              </div>
              <NavItems />
            </motion.aside>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Desktop sidebar */}
      <aside className="hidden lg:flex w-60 bg-white border-r border-gray-200 flex-col flex-shrink-0">
        <div className="p-5 border-b">
          <span className="text-lg font-bold text-blue-700">FollowUp AI</span>
        </div>
        <div className="px-3 py-3 border-b">
          <div className="flex items-center gap-2 px-3">
            <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center"><Building2 className="w-4 h-4 text-blue-600" /></div>
            <div><div className="text-sm font-semibold text-gray-900 truncate max-w-[140px]">{business.name}</div><div className="text-xs text-gray-400 capitalize">{userRole.toLowerCase()}</div></div>
          </div>
        </div>
        <NavItems />
      </aside>
    </>
  );
}
