
"use client";
import { useRef, useMemo } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { Text, Sphere, Line, OrbitControls } from "@react-three/drei";
import * as THREE from "three";

function Node({ position, label, color }: { position: [number,number,number]; label: string; color: string }) {
  const ref = useRef<THREE.Mesh>(null);
  useFrame((state) => {
    if (ref.current) ref.current.position.y = position[1] + Math.sin(state.clock.elapsedTime * 0.8 + position[0]) * 0.1;
  });
  return (
    <group position={position}>
      <Sphere ref={ref} args={[0.35, 32, 32]}>
        <meshStandardMaterial color={color} roughness={0.3} metalness={0.4} />
      </Sphere>
      <Text position={[0, -0.6, 0]} fontSize={0.22} color="#1e3a5f" anchorX="center">{label}</Text>
    </group>
  );
}

function ConnectingLines() {
  const positions: [number,number,number][] = [[-3,0,0],[-1,0,0],[1,0,0],[3,0,0]];
  return (
    <>
      {positions.slice(0,-1).map((p,i) => (
        <Line key={i} points={[p, positions[i+1]]} color="#93c5fd" lineWidth={2} dashed dashSize={0.2} gapSize={0.1} />
      ))}
    </>
  );
}

function Scene() {
  const nodes = useMemo(() => [
    { pos: [-3,0,0] as [number,number,number], label: "Lead", color: "#3b82f6" },
    { pos: [-1,0,0] as [number,number,number], label: "Follow-up", color: "#8b5cf6" },
    { pos: [1,0,0] as [number,number,number], label: "Message", color: "#06b6d4" },
    { pos: [3,0,0] as [number,number,number], label: "Enrolled", color: "#10b981" },
  ], []);
  return (
    <>
      <ambientLight intensity={0.6} />
      <directionalLight position={[5, 5, 5]} intensity={0.8} />
      <ConnectingLines />
      {nodes.map(n => <Node key={n.label} position={n.pos} label={n.label} color={n.color} />)}
      <OrbitControls enableZoom={false} enablePan={false} autoRotate autoRotateSpeed={0.5} maxPolarAngle={Math.PI/2} minPolarAngle={Math.PI/2} />
    </>
  );
}

export default function LeadFlowScene() {
  return (
    <div className="w-full h-full bg-gradient-to-br from-slate-50 to-blue-50">
      <Canvas camera={{ position: [0, 0, 6], fov: 50 }}>
        <Scene />
      </Canvas>
    </div>
  );
}
