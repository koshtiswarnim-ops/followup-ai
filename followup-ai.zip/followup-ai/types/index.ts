
export type ApiResponse<T> = { success: true; data: T } | { success: false; error: { code: string; message: string } }

export interface LeadFilters {
  status?: string; source?: string; assignedTo?: string;
  search?: string; page?: number; limit?: number;
}

export interface DashboardStats {
  totalLeads: number; newLeads: number; followUpsDue: number;
  converted: number; conversionRate: number; activeFollowUps: number;
}
