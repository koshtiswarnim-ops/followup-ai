import { Resend } from 'resend'

const resend = new Resend(process.env.RESEND_API_KEY)
const FROM = process.env.RESEND_FROM_EMAIL || 'noreply@followupai.in'
const APP_NAME = process.env.NEXT_PUBLIC_APP_NAME || 'FollowUp AI'
const APP_URL = process.env.NEXT_PUBLIC_APP_URL || 'https://followupai.in'

export async function sendWelcomeEmail(to: string, name: string, businessName: string) {
  if (process.env.DEMO_MODE === 'true') {
    console.log('[DEMO] Welcome email to:', to)
    return { id: 'demo-id' }
  }
  return resend.emails.send({
    from: FROM, to,
    subject: `Welcome to ${APP_NAME}, ${name}! 🎉`,
    html: `<div style="font-family:sans-serif;max-width:600px;margin:0 auto;padding:40px 20px">
      <h1 style="color:#1d4ed8">Welcome to ${APP_NAME}!</h1>
      <p>Hi ${name},</p>
      <p>Your account for <strong>${businessName}</strong> is ready. Start capturing leads and never miss a follow-up again.</p>
      <a href="${APP_URL}/dashboard" style="background:#1d4ed8;color:white;padding:12px 24px;border-radius:6px;text-decoration:none;display:inline-block;margin:20px 0">Go to Dashboard →</a>
      <p style="color:#6b7280;font-size:14px">If you have any questions, reply to this email. We're here to help!</p>
      <p style="color:#6b7280;font-size:14px">— Team ${APP_NAME}</p>
    </div>`,
  })
}

export async function sendFollowUpReminderEmail(to: string, name: string, studentName: string, scheduledAt: Date) {
  if (process.env.DEMO_MODE === 'true') {
    console.log('[DEMO] Reminder email to:', to)
    return { id: 'demo-id' }
  }
  return resend.emails.send({
    from: FROM, to,
    subject: `⏰ Follow-up due for ${studentName}`,
    html: `<div style="font-family:sans-serif;max-width:600px;margin:0 auto;padding:40px 20px">
      <h2 style="color:#1d4ed8">Follow-up Reminder</h2>
      <p>Hi ${name},</p>
      <p>You have a follow-up scheduled for <strong>${studentName}</strong> at <strong>${scheduledAt.toLocaleString('en-IN')}</strong>.</p>
      <a href="${APP_URL}/dashboard/leads" style="background:#1d4ed8;color:white;padding:12px 24px;border-radius:6px;text-decoration:none;display:inline-block;margin:20px 0">View Leads →</a>
    </div>`,
  })
}

export async function sendDailySummaryEmail(to: string, name: string, stats: { totalLeads: number; followUpsDue: number; converted: number }) {
  if (process.env.DEMO_MODE === 'true') {
    console.log('[DEMO] Daily summary email to:', to)
    return { id: 'demo-id' }
  }
  return resend.emails.send({
    from: FROM, to,
    subject: `📊 Your Daily Summary — ${new Date().toLocaleDateString('en-IN')}`,
    html: `<div style="font-family:sans-serif;max-width:600px;margin:0 auto;padding:40px 20px">
      <h2 style="color:#1d4ed8">Daily Summary</h2>
      <p>Hi ${name}, here's your summary for today:</p>
      <table style="width:100%;border-collapse:collapse;margin:20px 0">
        <tr><td style="padding:12px;border:1px solid #e5e7eb">Total Leads</td><td style="padding:12px;border:1px solid #e5e7eb;font-weight:bold">${stats.totalLeads}</td></tr>
        <tr><td style="padding:12px;border:1px solid #e5e7eb">Follow-ups Due</td><td style="padding:12px;border:1px solid #e5e7eb;font-weight:bold;color:#f59e0b">${stats.followUpsDue}</td></tr>
        <tr><td style="padding:12px;border:1px solid #e5e7eb">Converted Today</td><td style="padding:12px;border:1px solid #e5e7eb;font-weight:bold;color:#10b981">${stats.converted}</td></tr>
      </table>
      <a href="${APP_URL}/dashboard" style="background:#1d4ed8;color:white;padding:12px 24px;border-radius:6px;text-decoration:none;display:inline-block">Go to Dashboard →</a>
    </div>`,
  })
}

export async function sendSubscriptionConfirmationEmail(to: string, name: string, plan: string) {
  if (process.env.DEMO_MODE === 'true') return { id: 'demo-id' }
  return resend.emails.send({
    from: FROM, to,
    subject: `✅ Subscription Confirmed — ${plan} Plan`,
    html: `<div style="font-family:sans-serif;max-width:600px;margin:0 auto;padding:40px 20px">
      <h2 style="color:#10b981">Subscription Confirmed!</h2>
      <p>Hi ${name}, you're now on the <strong>${plan}</strong> plan. Enjoy all your new features!</p>
      <a href="${APP_URL}/dashboard/billing" style="background:#1d4ed8;color:white;padding:12px 24px;border-radius:6px;text-decoration:none;display:inline-block;margin:20px 0">View Billing →</a>
    </div>`,
  })
}

export async function sendPaymentFailedEmail(to: string, name: string) {
  if (process.env.DEMO_MODE === 'true') return { id: 'demo-id' }
  return resend.emails.send({
    from: FROM, to,
    subject: `⚠️ Payment Failed — Action Required`,
    html: `<div style="font-family:sans-serif;max-width:600px;margin:0 auto;padding:40px 20px">
      <h2 style="color:#ef4444">Payment Failed</h2>
      <p>Hi ${name}, we couldn't process your recent payment. Please update your payment details to continue using ${APP_NAME}.</p>
      <a href="${APP_URL}/dashboard/billing" style="background:#ef4444;color:white;padding:12px 24px;border-radius:6px;text-decoration:none;display:inline-block;margin:20px 0">Update Payment →</a>
    </div>`,
  })
}
