import { auth, currentUser } from '@clerk/nextjs/server'
import { prisma } from './prisma'
import { Role } from '@prisma/client'

export async function getCurrentUser() {
  const { userId } = auth()
  if (!userId) return null

  const user = await prisma.user.findUnique({
    where: { clerkUserId: userId },
  })
  return user
}

export async function requireAuth() {
  const { userId } = auth()
  if (!userId) throw new Error('Unauthorized')

  const user = await prisma.user.findUnique({
    where: { clerkUserId: userId },
  })
  if (!user) throw new Error('User not found')
  return user
}

export async function requireBusinessAccess(businessId: string, minRole: Role = 'STAFF') {
  const user = await requireAuth()

  const member = await prisma.businessMember.findUnique({
    where: { businessId_userId: { businessId, userId: user.id } },
    include: { business: true },
  })

  if (!member) throw new Error('Forbidden: not a member of this business')

  const roleHierarchy: Record<Role, number> = { STAFF: 1, ADMIN: 2, OWNER: 3 }
  if (roleHierarchy[member.role] < roleHierarchy[minRole]) {
    throw new Error('Forbidden: insufficient permissions')
  }

  return { user, member, business: member.business }
}

export async function getUserBusiness(userId: string) {
  const member = await prisma.businessMember.findFirst({
    where: { userId },
    include: { business: true },
    orderBy: { createdAt: 'asc' },
  })
  return member
}

export function canManageTeam(role: Role): boolean {
  return role === 'OWNER' || role === 'ADMIN'
}

export function canManageBilling(role: Role): boolean {
  return role === 'OWNER'
}

export function canDeleteLeads(role: Role): boolean {
  return role === 'OWNER' || role === 'ADMIN'
}
