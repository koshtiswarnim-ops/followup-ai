interface SendWhatsAppParams {
  to: string
  message: string
  phoneNumberId?: string
  token?: string
}

interface WhatsAppResponse {
  success: boolean
  messageId?: string
  error?: string
  demo?: boolean
}

export async function sendWhatsAppMessage(params: SendWhatsAppParams): Promise<WhatsAppResponse> {
  const isDemoMode = process.env.DEMO_MODE === 'true'
  if (isDemoMode || !process.env.WHATSAPP_TOKEN) {
    console.log('[DEMO] WhatsApp message to:', params.to, '\nMessage:', params.message)
    return { success: true, messageId: `demo-${Date.now()}`, demo: true }
  }

  const phoneNumberId = params.phoneNumberId || process.env.WHATSAPP_PHONE_NUMBER_ID
  const token = params.token || process.env.WHATSAPP_TOKEN
  const cleanPhone = params.to.replace(/[^0-9]/g, '')
  const phone = cleanPhone.startsWith('91') ? cleanPhone : `91${cleanPhone}`

  try {
    const res = await fetch(
      `https://graph.facebook.com/v19.0/${phoneNumberId}/messages`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({
          messaging_product: 'whatsapp',
          to: phone,
          type: 'text',
          text: { preview_url: false, body: params.message },
        }),
      }
    )
    const data = await res.json()
    if (!res.ok) return { success: false, error: data.error?.message || 'WhatsApp API error' }
    return { success: true, messageId: data.messages?.[0]?.id }
  } catch (err: any) {
    return { success: false, error: err.message }
  }
}

export function verifyWhatsAppWebhook(token: string, challenge: string, verifyToken: string): string | null {
  if (token === verifyToken) return challenge
  return null
}

export function parseWhatsAppWebhookPayload(body: any): WhatsAppIncomingMessage[] {
  const messages: WhatsAppIncomingMessage[] = []
  try {
    const entries = body.entry || []
    for (const entry of entries) {
      for (const change of entry.changes || []) {
        if (change.field !== 'messages') continue
        for (const msg of change.value?.messages || []) {
          messages.push({
            from: msg.from,
            messageId: msg.id,
            timestamp: parseInt(msg.timestamp),
            text: msg.text?.body || '',
            type: msg.type,
            phoneNumberId: change.value.metadata?.phone_number_id,
          })
        }
      }
    }
  } catch {}
  return messages
}

export interface WhatsAppIncomingMessage {
  from: string
  messageId: string
  timestamp: number
  text: string
  type: string
  phoneNumberId: string
}
