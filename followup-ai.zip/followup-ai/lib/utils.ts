
import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatDate(date: string | Date): string {
  return new Date(date).toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" });
}

export function formatRelativeTime(date: string | Date): string {
  const diff = Date.now() - new Date(date).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.floor(hrs / 24)}d ago`;
}

export function getStatusColor(status: string): string {
  const map: Record<string, string> = {
    NEW: "bg-blue-100 text-blue-700",
    CONTACTED: "bg-yellow-100 text-yellow-700",
    INTERESTED: "bg-purple-100 text-purple-700",
    FOLLOW_UP: "bg-orange-100 text-orange-700",
    CONVERTED: "bg-green-100 text-green-700",
    LOST: "bg-red-100 text-red-700",
  };
  return map[status] || "bg-gray-100 text-gray-700";
}

export function getSourceLabel(source: string): string {
  const map: Record<string, string> = {
    WEBSITE: "Website", WHATSAPP: "WhatsApp", INSTAGRAM: "Instagram",
    FACEBOOK: "Facebook", REFERRAL: "Referral", WALK_IN: "Walk-in", OTHER: "Other",
  };
  return map[source] || source;
}

export interface PlanLimits { leads: number; aiMessages: number; teamMembers: number; }

export function getPlanLimits(plan: string): PlanLimits {
  const limits: Record<string, PlanLimits> = {
    FREE:   { leads: 100,  aiMessages: 20,   teamMembers: 2 },
    GROWTH: { leads: 1000, aiMessages: 200,  teamMembers: 5 },
    PRO:    { leads: 5000, aiMessages: 1000, teamMembers: 20 },
  };
  return limits[plan] || limits.FREE;
}
