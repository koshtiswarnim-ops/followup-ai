
"use client";
import { useEffect, useState } from "react";
import { BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend } from "recharts";
import { Loader2 } from "lucide-react";

const STATUS_COLORS: Record<string, string> = { NEW: "#3b82f6", CONTACTED: "#f59e0b", INTERESTED: "#8b5cf6", FOLLOW_UP: "#f97316", CONVERTED: "#10b981", LOST: "#ef4444" };
const SOURCE_COLORS = ["#3b82f6","#10b981","#f59e0b","#8b5cf6","#f97316","#ef4444","#06b6d4"];

export default function AnalyticsPage() {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/analytics").then(r => r.json()).then(d => { if (d.success) setData(d.data); setLoading(false); });
  }, []);

  if (loading) return <div className="flex items-center justify-center h-64"><Loader2 className="w-6 h-6 animate-spin text-blue-500" /></div>;
  if (!data) return <p className="text-gray-500">Failed to load analytics.</p>;

  const STAT_CARDS = [
    { label: "Total Leads", value: data.stats.totalLeads, color: "blue" },
    { label: "Converted", value: data.stats.converted, color: "green" },
    { label: "Follow-ups Due", value: data.stats.followUpsDue, color: "yellow" },
    { label: "Conversion Rate", value: `${data.stats.conversionRate}%`, color: "purple" },
  ];

  return (
    <div className="space-y-6">
      <div><h1 className="text-2xl font-bold text-gray-900">Analytics</h1><p className="text-sm text-gray-500">Your lead and performance overview</p></div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {STAT_CARDS.map(s => (
          <div key={s.label} className="bg-white rounded-xl border border-gray-200 p-5 shadow-sm">
            <div className="text-2xl font-bold text-gray-900">{s.value}</div>
            <div className="text-sm text-gray-500 mt-1">{s.label}</div>
          </div>
        ))}
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl border border-gray-200 p-6 shadow-sm">
          <h3 className="font-semibold mb-4">Lead Status Breakdown</h3>
          <ResponsiveContainer width="100%" height={250}>
            <PieChart>
              <Pie data={data.byStatus} cx="50%" cy="50%" outerRadius={90} dataKey="value" nameKey="name" label={({ name, percent }) => `${name} ${(percent*100).toFixed(0)}%`}>
                {data.byStatus.map((s: any, i: number) => <Cell key={i} fill={STATUS_COLORS[s.name] || "#6b7280"} />)}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white rounded-xl border border-gray-200 p-6 shadow-sm">
          <h3 className="font-semibold mb-4">Lead Sources</h3>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={data.bySource} margin={{ left: -20 }}>
              <XAxis dataKey="name" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} />
              <Tooltip />
              <Bar dataKey="value" radius={[4,4,0,0]}>
                {data.bySource.map((_: any, i: number) => <Cell key={i} fill={SOURCE_COLORS[i % SOURCE_COLORS.length]} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
