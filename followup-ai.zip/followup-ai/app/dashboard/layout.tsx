
import { auth } from "@clerk/nextjs/server";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/prisma";
import DashboardSidebar from "@/components/dashboard/Sidebar";
import DashboardHeader from "@/components/dashboard/Header";

export default async function DashboardLayout({ children }: { children: React.ReactNode }) {
  const { userId } = auth();
  if (!userId) redirect("/sign-in");

  const user = await prisma.user.findUnique({ where: { clerkUserId: userId } });
  if (!user) redirect("/onboarding");

  const member = await prisma.businessMember.findFirst({
    where: { userId: user.id },
    include: { business: { include: { subscription: true } } },
  });
  if (!member) redirect("/onboarding");

  return (
    <div className="min-h-screen bg-gray-50 flex">
      <DashboardSidebar business={member.business} userRole={member.role} />
      <div className="flex-1 flex flex-col min-w-0">
        <DashboardHeader user={user} business={member.business} />
        <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-auto">{children}</main>
      </div>
    </div>
  );
}
