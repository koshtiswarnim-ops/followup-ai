
"use client";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Brain, Copy, Send, RotateCcw, Loader2, CheckCircle2, AlertCircle } from "lucide-react";

const SITUATIONS = ["First follow-up","Fee enquiry","Student stopped responding","Course reminder","Admission deadline","Counselling reminder","Last follow-up"];
const TONES = ["Professional","Friendly","Helpful","Urgent","Conversational"];
const CHANNELS = ["WhatsApp","Email","SMS"];

export default function AIMessagesPage() {
  const [leadId, setLeadId] = useState("");
  const [situation, setSituation] = useState(SITUATIONS[0]);
  const [tone, setTone] = useState(TONES[0]);
  const [channel, setChannel] = useState(CHANNELS[0]);
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [copied, setCopied] = useState(false);

  async function generate() {
    setLoading(true); setError("");
    try {
      const res = await fetch("/api/ai/generate-message", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ leadId: leadId || undefined, situation, tone, channel }),
      });
      const data = await res.json();
      if (data.success) setMessage(data.data.message);
      else setError(data.error?.message || "Failed to generate message");
    } catch { setError("Network error. Please try again."); }
    setLoading(false);
  }

  function copy() {
    navigator.clipboard.writeText(message);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">AI Message Generator</h1>
        <p className="text-gray-500 text-sm mt-1">Generate personalized follow-up messages powered by AI.</p>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-6 space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Situation</label>
            <select value={situation} onChange={e => setSituation(e.target.value)} className="w-full border rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
              {SITUATIONS.map(s => <option key={s}>{s}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Tone</label>
            <select value={tone} onChange={e => setTone(e.target.value)} className="w-full border rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
              {TONES.map(t => <option key={t}>{t}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Channel</label>
            <select value={channel} onChange={e => setChannel(e.target.value)} className="w-full border rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
              {CHANNELS.map(c => <option key={c}>{c}</option>)}
            </select>
          </div>
        </div>

        <button onClick={generate} disabled={loading}
          className="w-full bg-blue-600 text-white py-3 rounded-xl font-semibold hover:bg-blue-700 transition flex items-center justify-center gap-2 disabled:opacity-50">
          {loading ? <><Loader2 className="w-4 h-4 animate-spin" /> Generating...</> : <><Brain className="w-4 h-4" /> Generate Message</>}
        </button>

        {error && (
          <div className="flex items-start gap-2 text-red-600 text-sm bg-red-50 rounded-lg p-3">
            <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" /> {error}
          </div>
        )}
      </div>

      <AnimatePresence>
        {message && (
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="bg-white rounded-xl border border-gray-200 shadow-sm p-6 space-y-4">
            <div className="flex items-center gap-2 text-xs text-amber-600 bg-amber-50 px-3 py-1.5 rounded-lg font-medium">
              <AlertCircle className="w-3.5 h-3.5" /> AI-generated · Review before sending
            </div>
            <textarea value={message} onChange={e => setMessage(e.target.value)}
              className="w-full border rounded-lg p-3 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-blue-500 min-h-[140px]" />
            <div className="flex gap-3">
              <button onClick={generate} disabled={loading} className="flex items-center gap-2 border rounded-lg px-4 py-2 text-sm font-medium hover:bg-gray-50 transition">
                <RotateCcw className="w-3.5 h-3.5" /> Regenerate
              </button>
              <button onClick={copy} className="flex items-center gap-2 border rounded-lg px-4 py-2 text-sm font-medium hover:bg-gray-50 transition">
                {copied ? <CheckCircle2 className="w-3.5 h-3.5 text-green-600" /> : <Copy className="w-3.5 h-3.5" />} {copied ? "Copied!" : "Copy"}
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
