
import { auth } from "@clerk/nextjs/server";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { formatDate, formatRelativeTime, getStatusColor, getSourceLabel } from "@/lib/utils";
import { TrendingUp, Users, Zap, CheckCircle2, BarChart3, ArrowRight } from "lucide-react";
import Link from "next/link";

export default async function DashboardPage() {
  const { userId } = auth();
  if (!userId) redirect("/sign-in");
  const user = await prisma.user.findUnique({ where: { clerkUserId: userId } });
  if (!user) redirect("/onboarding");
  const member = await prisma.businessMember.findFirst({ where: { userId: user.id } });
  if (!member) redirect("/onboarding");
  const bid = member.businessId;
  const now = new Date();
  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);

  const [totalLeads, newLeads, converted, followUpsDue, recentLeads, todayFollowUps, activities] = await Promise.all([
    prisma.lead.count({ where: { businessId: bid } }),
    prisma.lead.count({ where: { businessId: bid, createdAt: { gte: monthStart } } }),
    prisma.lead.count({ where: { businessId: bid, status: "CONVERTED" } }),
    prisma.followUp.count({ where: { businessId: bid, status: "PENDING", scheduledAt: { lte: now } } }),
    prisma.lead.findMany({ where: { businessId: bid }, orderBy: { createdAt: "desc" }, take: 5, include: { assignedUser: { select: { name: true } } } }),
    prisma.followUp.findMany({ where: { businessId: bid, status: "PENDING", scheduledAt: { lte: new Date(now.getTime() + 86400000) } }, take: 5, include: { lead: { select: { name: true, phone: true } } }, orderBy: { scheduledAt: "asc" } }),
    prisma.activity.findMany({ where: { businessId: bid }, orderBy: { createdAt: "desc" }, take: 8, include: { user: { select: { name: true } }, lead: { select: { name: true } } } }),
  ]);

  const conversionRate = totalLeads > 0 ? Math.round((converted / totalLeads) * 100) : 0;

  const STATS = [
    { label: "Total Leads", value: totalLeads, icon: Users, color: "blue", sub: `${newLeads} new this month` },
    { label: "Follow-ups Due", value: followUpsDue, icon: Zap, color: "yellow", sub: "Need attention now", href: "/dashboard/follow-ups" },
    { label: "Converted", value: converted, icon: CheckCircle2, color: "green", sub: `${conversionRate}% conversion rate` },
    { label: "Conversion Rate", value: `${conversionRate}%`, icon: TrendingUp, color: "purple", sub: "Overall" },
  ];

  const colorMap: Record<string, string> = { blue: "bg-blue-50 text-blue-600", yellow: "bg-yellow-50 text-yellow-600", green: "bg-green-50 text-green-600", purple: "bg-purple-50 text-purple-600" };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
        <p className="text-gray-500 text-sm mt-1">Welcome back, {user.name.split(" ")[0]}!</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {STATS.map(s => (
          <div key={s.label} className="bg-white rounded-xl border border-gray-200 p-5 shadow-sm">
            <div className="flex items-center justify-between mb-3">
              <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${colorMap[s.color]}`}>
                <s.icon className="w-4 h-4" />
              </div>
            </div>
            <div className="text-2xl font-bold text-gray-900">{s.value}</div>
            <div className="text-sm font-medium text-gray-700 mt-0.5">{s.label}</div>
            <div className="text-xs text-gray-400 mt-0.5">{s.sub}</div>
          </div>
        ))}
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Recent leads */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-gray-200 shadow-sm">
          <div className="flex items-center justify-between p-5 border-b">
            <h2 className="font-semibold text-gray-900">Recent Leads</h2>
            <Link href="/dashboard/leads" className="text-sm text-blue-600 hover:underline flex items-center gap-1">View all <ArrowRight className="w-3 h-3" /></Link>
          </div>
          <div className="divide-y">
            {recentLeads.length === 0 && <p className="text-sm text-gray-500 p-5">No leads yet. <Link href="/dashboard/leads" className="text-blue-600 hover:underline">Add your first lead →</Link></p>}
            {recentLeads.map(lead => (
              <Link key={lead.id} href={`/dashboard/leads/${lead.id}`} className="flex items-center gap-4 p-4 hover:bg-gray-50 transition">
                <div className="w-9 h-9 rounded-full bg-blue-100 flex items-center justify-center text-blue-700 font-semibold text-sm flex-shrink-0">{lead.name[0]}</div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium text-gray-900 truncate">{lead.name}</div>
                  <div className="text-xs text-gray-500">{lead.course || "—"} · {getSourceLabel(lead.source)}</div>
                </div>
                <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${getStatusColor(lead.status)}`}>{lead.status.replace("_"," ")}</span>
              </Link>
            ))}
          </div>
        </div>

        {/* Today's follow-ups */}
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm">
          <div className="flex items-center justify-between p-5 border-b">
            <h2 className="font-semibold text-gray-900">Due Follow-ups</h2>
            <Link href="/dashboard/follow-ups" className="text-sm text-blue-600 hover:underline">All</Link>
          </div>
          <div className="divide-y">
            {todayFollowUps.length === 0 && <p className="text-sm text-gray-500 p-5">No pending follow-ups. You're all caught up! 🎉</p>}
            {todayFollowUps.map(fu => (
              <div key={fu.id} className="p-4">
                <div className="text-sm font-medium text-gray-900">{fu.lead?.name}</div>
                <div className="text-xs text-gray-500 mt-0.5">{fu.channel} · {formatDate(fu.scheduledAt)}</div>
                <div className={`text-xs mt-1 inline-flex px-2 py-0.5 rounded-full font-medium ${new Date(fu.scheduledAt) < now ? "bg-red-100 text-red-700" : "bg-yellow-100 text-yellow-700"}`}>
                  {new Date(fu.scheduledAt) < now ? "Overdue" : "Due soon"}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Activity */}
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm">
        <div className="p-5 border-b"><h2 className="font-semibold text-gray-900">Recent Activity</h2></div>
        <div className="divide-y">
          {activities.length === 0 && <p className="text-sm text-gray-500 p-5">No activity yet.</p>}
          {activities.map(a => (
            <div key={a.id} className="flex items-start gap-3 p-4">
              <div className="w-2 h-2 bg-blue-400 rounded-full mt-2 flex-shrink-0" />
              <div className="flex-1">
                <div className="text-sm text-gray-900">{a.description}</div>
                {a.lead && <div className="text-xs text-gray-500">{a.lead.name}</div>}
              </div>
              <div className="text-xs text-gray-400 whitespace-nowrap">{formatRelativeTime(a.createdAt)}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
