
"use client";
import { useState, useEffect, useCallback } from "react";
import { motion } from "framer-motion";
import { Plus, Search, Filter, ChevronLeft, ChevronRight, Loader2, Trash2, Edit, Eye } from "lucide-react";
import Link from "next/link";
import { formatDate, getStatusColor, getSourceLabel, cn } from "@/lib/utils";

const STATUSES = ["ALL","NEW","CONTACTED","INTERESTED","FOLLOW_UP","CONVERTED","LOST"];
const SOURCES = ["ALL","WEBSITE","WHATSAPP","INSTAGRAM","FACEBOOK","REFERRAL","WALK_IN","OTHER"];

interface Lead { id: string; name: string; phone?: string; email?: string; course?: string; source: string; status: string; createdAt: string; assignedUser?: { name: string }; followUps?: any[] }

export default function LeadsPage() {
  const [leads, setLeads] = useState<Lead[]>([]);
  const [total, setTotal] = useState(0);
  const [pages, setPages] = useState(1);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("ALL");
  const [source, setSource] = useState("ALL");
  const [showAdd, setShowAdd] = useState(false);
  const [addForm, setAddForm] = useState({ name: "", phone: "", email: "", course: "", source: "OTHER" });
  const [addLoading, setAddLoading] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    const params = new URLSearchParams({ page: String(page), limit: "20" });
    if (search) params.set("search", search);
    if (status !== "ALL") params.set("status", status);
    if (source !== "ALL") params.set("source", source);
    const res = await fetch(`/api/leads?${params}`);
    const data = await res.json();
    if (data.success) { setLeads(data.data.leads); setTotal(data.data.total); setPages(data.data.pages); }
    setLoading(false);
  }, [page, search, status, source]);

  useEffect(() => { load(); }, [load]);

  async function addLead(e: React.FormEvent) {
    e.preventDefault(); setAddLoading(true);
    const res = await fetch("/api/leads", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(addForm) });
    const data = await res.json();
    if (data.success) { setShowAdd(false); setAddForm({ name: "", phone: "", email: "", course: "", source: "OTHER" }); load(); }
    setAddLoading(false);
  }

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div><h1 className="text-2xl font-bold text-gray-900">Leads</h1><p className="text-sm text-gray-500">{total} total leads</p></div>
        <button onClick={() => setShowAdd(true)} className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-blue-700 transition">
          <Plus className="w-4 h-4" /> Add Lead
        </button>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-xl border border-gray-200 p-4 flex flex-wrap gap-3">
        <div className="relative flex-1 min-w-48">
          <Search className="absolute left-3 top-2.5 w-4 h-4 text-gray-400" />
          <input value={search} onChange={e => { setSearch(e.target.value); setPage(1); }} placeholder="Search by name, phone, email..."
            className="pl-9 pr-3 py-2 text-sm border rounded-lg w-full focus:outline-none focus:ring-2 focus:ring-blue-500" />
        </div>
        <select value={status} onChange={e => { setStatus(e.target.value); setPage(1); }} className="border rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
          {STATUSES.map(s => <option key={s}>{s}</option>)}
        </select>
        <select value={source} onChange={e => { setSource(e.target.value); setPage(1); }} className="border rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
          {SOURCES.map(s => <option key={s}>{s}</option>)}
        </select>
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 border-b">
              <tr>{["Name","Phone","Course","Source","Status","Counsellor","Added","Actions"].map(h => <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide">{h}</th>)}</tr>
            </thead>
            <tbody className="divide-y">
              {loading && <tr><td colSpan={8} className="text-center py-12"><Loader2 className="w-6 h-6 animate-spin mx-auto text-blue-500" /></td></tr>}
              {!loading && leads.length === 0 && <tr><td colSpan={8} className="text-center py-12 text-gray-400">No leads found. Add your first lead!</td></tr>}
              {!loading && leads.map(lead => (
                <tr key={lead.id} className="hover:bg-gray-50 transition">
                  <td className="px-4 py-3"><Link href={`/dashboard/leads/${lead.id}`} className="font-medium text-gray-900 hover:text-blue-600">{lead.name}</Link></td>
                  <td className="px-4 py-3 text-gray-500">{lead.phone || "—"}</td>
                  <td className="px-4 py-3 text-gray-500 truncate max-w-[120px]">{lead.course || "—"}</td>
                  <td className="px-4 py-3 text-gray-500">{getSourceLabel(lead.source)}</td>
                  <td className="px-4 py-3"><span className={`px-2 py-0.5 rounded-full text-xs font-medium ${getStatusColor(lead.status)}`}>{lead.status.replace("_"," ")}</span></td>
                  <td className="px-4 py-3 text-gray-500">{lead.assignedUser?.name || "—"}</td>
                  <td className="px-4 py-3 text-gray-400">{formatDate(lead.createdAt)}</td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <Link href={`/dashboard/leads/${lead.id}`} className="p-1.5 rounded hover:bg-blue-50 text-blue-600 transition"><Eye className="w-4 h-4" /></Link>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {pages > 1 && (
          <div className="flex items-center justify-between px-4 py-3 border-t">
            <p className="text-sm text-gray-500">Page {page} of {pages} · {total} leads</p>
            <div className="flex gap-2">
              <button onClick={() => setPage(p => Math.max(1, p-1))} disabled={page === 1} className="p-1.5 rounded hover:bg-gray-100 disabled:opacity-40"><ChevronLeft className="w-4 h-4" /></button>
              <button onClick={() => setPage(p => Math.min(pages, p+1))} disabled={page === pages} className="p-1.5 rounded hover:bg-gray-100 disabled:opacity-40"><ChevronRight className="w-4 h-4" /></button>
            </div>
          </div>
        )}
      </div>

      {/* Add Lead Modal */}
      {showAdd && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40">
          <motion.div initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="bg-white rounded-2xl p-6 w-full max-w-md shadow-xl">
            <h2 className="text-lg font-bold mb-4">Add New Lead</h2>
            <form onSubmit={addLead} className="space-y-3">
              <input required value={addForm.name} onChange={e => setAddForm(p => ({...p,name:e.target.value}))} placeholder="Student Name *" className="w-full border rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
              <input value={addForm.phone} onChange={e => setAddForm(p => ({...p,phone:e.target.value}))} placeholder="Phone Number" className="w-full border rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
              <input type="email" value={addForm.email} onChange={e => setAddForm(p => ({...p,email:e.target.value}))} placeholder="Email" className="w-full border rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
              <input value={addForm.course} onChange={e => setAddForm(p => ({...p,course:e.target.value}))} placeholder="Course (e.g. JEE Main 2027)" className="w-full border rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
              <select value={addForm.source} onChange={e => setAddForm(p => ({...p,source:e.target.value}))} className="w-full border rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                {SOURCES.filter(s => s !== "ALL").map(s => <option key={s} value={s}>{getSourceLabel(s)}</option>)}
              </select>
              <div className="flex gap-3 pt-2">
                <button type="button" onClick={() => setShowAdd(false)} className="flex-1 border rounded-lg py-2 text-sm font-medium hover:bg-gray-50">Cancel</button>
                <button type="submit" disabled={addLoading} className="flex-1 bg-blue-600 text-white rounded-lg py-2 text-sm font-medium hover:bg-blue-700 flex items-center justify-center gap-2 disabled:opacity-50">
                  {addLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : null} Add Lead
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}
    </div>
  );
}
