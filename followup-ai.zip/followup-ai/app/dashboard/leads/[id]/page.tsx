import { auth } from "@clerk/nextjs/server";
import { redirect, notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { formatDate, formatRelativeTime, getStatusColor, getSourceLabel } from "@/lib/utils";
import { ArrowLeft, Phone, Mail, BookOpen, Calendar, User, MessageSquare } from "lucide-react";
import Link from "next/link";

export default async function LeadDetailPage({ params }: { params: { id: string } }) {
  const { userId } = auth();
  if (!userId) redirect("/sign-in");
  const user = await prisma.user.findUnique({ where: { clerkUserId: userId } });
  if (!user) redirect("/onboarding");
  const member = await prisma.businessMember.findFirst({ where: { userId: user.id } });
  if (!member) redirect("/onboarding");

  const lead = await prisma.lead.findFirst({
    where: { id: params.id, businessId: member.businessId },
    include: {
      assignedUser: { select: { name: true, email: true } },
      followUps: { orderBy: { scheduledAt: "asc" }, include: { assignedUser: { select: { name: true } } } },
      activities: { orderBy: { createdAt: "desc" }, take: 30, include: { user: { select: { name: true } } } },
    },
  });
  if (!lead) notFound();

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex items-center gap-3">
        <Link href="/dashboard/leads" className="p-2 rounded-lg hover:bg-gray-100"><ArrowLeft className="w-4 h-4" /></Link>
        <div>
          <h1 className="text-2xl font-bold text-gray-900">{lead.name}</h1>
          <p className="text-sm text-gray-500">Added {formatDate(lead.createdAt)}</p>
        </div>
        <span className={`ml-auto px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(lead.status)}`}>
          {lead.status.replace("_", " ")}
        </span>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        <div className="space-y-4">
          <div className="bg-white rounded-xl border border-gray-200 p-5 space-y-3">
            <h3 className="font-semibold text-sm text-gray-700">Student Info</h3>
            {lead.phone && <div className="flex items-center gap-2 text-sm"><Phone className="w-4 h-4 text-gray-400" /><a href={`tel:${lead.phone}`} className="text-blue-600">{lead.phone}</a></div>}
            {lead.email && <div className="flex items-center gap-2 text-sm"><Mail className="w-4 h-4 text-gray-400" />{lead.email}</div>}
            {lead.course && <div className="flex items-center gap-2 text-sm"><BookOpen className="w-4 h-4 text-gray-400" />{lead.course}</div>}
            <div className="flex items-center gap-2 text-sm"><MessageSquare className="w-4 h-4 text-gray-400" />{getSourceLabel(lead.source)}</div>
            {lead.assignedUser && <div className="flex items-center gap-2 text-sm"><User className="w-4 h-4 text-gray-400" />{lead.assignedUser.name}</div>}
            {lead.lastContact && <div className="flex items-center gap-2 text-sm"><Calendar className="w-4 h-4 text-gray-400" />Last: {formatDate(lead.lastContact)}</div>}
          </div>
          {lead.notes && (
            <div className="bg-white rounded-xl border border-gray-200 p-5">
              <h3 className="font-semibold text-sm text-gray-700 mb-2">Notes</h3>
              <p className="text-sm text-gray-600 whitespace-pre-wrap">{lead.notes}</p>
            </div>
          )}
        </div>
        <div className="md:col-span-2 space-y-4">
          <div className="bg-white rounded-xl border border-gray-200">
            <div className="p-5 border-b"><h3 className="font-semibold">Follow-ups ({lead.followUps.length})</h3></div>
            <div className="divide-y">
              {lead.followUps.length === 0 && <p className="text-sm text-gray-500 p-5">No follow-ups scheduled.</p>}
              {lead.followUps.map(fu => (
                <div key={fu.id} className="p-4 flex items-start gap-3">
                  <div className={`w-2 h-2 rounded-full mt-2 flex-shrink-0 ${fu.status === "COMPLETED" ? "bg-green-400" : fu.status === "PENDING" ? "bg-yellow-400" : "bg-gray-300"}`} />
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium">{fu.channel}</span>
                      <span className="text-xs text-gray-400">{formatDate(fu.scheduledAt)}</span>
                      <span className="text-xs px-2 py-0.5 rounded-full bg-gray-100 text-gray-600">{fu.status}</span>
                    </div>
                    {fu.message && <p className="text-sm text-gray-600 mt-1 line-clamp-2">{fu.message}</p>}
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div className="bg-white rounded-xl border border-gray-200">
            <div className="p-5 border-b"><h3 className="font-semibold">Activity Timeline</h3></div>
            <div className="divide-y">
              {lead.activities.length === 0 && <p className="text-sm text-gray-500 p-5">No activity yet.</p>}
              {lead.activities.map(a => (
                <div key={a.id} className="flex items-start gap-3 p-4">
                  <div className="w-2 h-2 bg-blue-400 rounded-full mt-2 flex-shrink-0" />
                  <div className="flex-1">
                    <div className="text-sm text-gray-900">{a.description}</div>
                    <div className="text-xs text-gray-400">{a.user?.name} · {formatRelativeTime(a.createdAt)}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
