
import type { Metadata } from "next";
import { Inter } from "next/font/google";
import { ClerkProvider } from "@clerk/nextjs";
import "./globals.css";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "FollowUp AI – Stop Losing Students After Their First Enquiry",
  description: "Lead management and automated follow-up platform for coaching institutes in India.",
  keywords: ["coaching institute", "lead management", "follow-up automation", "WhatsApp CRM"],
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <ClerkProvider>
      <html lang="en">
        <body className={inter.className}>
          {process.env.DEMO_MODE === "true" && (
            <div className="demo-banner">⚠ Demo Mode – External messages are simulated</div>
          )}
          {children}
        </body>
      </html>
    </ClerkProvider>
  );
}
