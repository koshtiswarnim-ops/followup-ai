
"use client";
import { motion } from "framer-motion";
import Link from "next/link";
import dynamic from "next/dynamic";
import { ArrowRight, CheckCircle2, BarChart3, MessageSquare, Zap, Users, Brain, Bell, CreditCard, TrendingUp } from "lucide-react";

const LeadFlowScene = dynamic(() => import("@/components/landing/LeadFlowScene"), { ssr: false, loading: () => <div className="w-full h-full bg-gradient-to-br from-blue-50 to-indigo-100 rounded-2xl" /> });

const FEATURES = [
  { icon: Users, title: "Lead Management", desc: "Capture, track, and manage every student enquiry from multiple sources in one place." },
  { icon: Zap, title: "Automated Follow-ups", desc: "Schedule intelligent follow-up sequences – Day 1, 3, 7, 14 – without lifting a finger." },
  { icon: Brain, title: "AI Message Generation", desc: "Generate personalized WhatsApp messages tailored to each student's profile and situation." },
  { icon: MessageSquare, title: "WhatsApp Integration", desc: "Official WhatsApp Business API integration for seamless student communication." },
  { icon: Users, title: "Counsellor Management", desc: "Assign leads, track activity, and monitor counsellor performance from one dashboard." },
  { icon: BarChart3, title: "Analytics & Reports", desc: "Deep insights into conversion rates, counsellor performance, and lead sources." },
  { icon: TrendingUp, title: "Lead Sources", desc: "Track leads from Website, Instagram, Facebook, WhatsApp, Referrals, and Walk-ins." },
  { icon: MessageSquare, title: "Message Templates", desc: "Build a library of proven templates with dynamic variables for instant personalisation." },
  { icon: Bell, title: "Smart Notifications", desc: "Never miss a follow-up with real-time alerts for due and overdue actions." },
  { icon: CreditCard, title: "Subscription Management", desc: "Flexible plans that grow with your institute – Free, Growth, and Pro." },
];

const STEPS = [
  { n: "01", title: "Capture Leads", desc: "Collect enquiries from all channels – website, Instagram, WhatsApp, and walk-ins." },
  { n: "02", title: "Track Conversations", desc: "See every interaction, note, and message in a single lead timeline." },
  { n: "03", title: "Automate Follow-ups", desc: "AI schedules and drafts follow-up messages so counsellors never forget a student." },
  { n: "04", title: "Convert Students", desc: "Move leads from enquiry to enrollment with less effort and more precision." },
];

const PLANS = [
  { name: "FREE", price: "₹0", sub: "/month", highlight: false, features: ["Up to 100 leads", "Basic follow-ups", "20 AI messages", "Basic dashboard"] },
  { name: "GROWTH", price: "₹999", sub: "/month", highlight: true, features: ["Up to 1,000 leads", "Automated follow-ups", "200 AI messages", "WhatsApp integration", "Analytics", "Templates", "5 team members"] },
  { name: "PRO", price: "₹1,999", sub: "/month", highlight: false, features: ["Up to 5,000 leads", "Advanced analytics", "1,000 AI messages", "Team management", "Advanced automation", "Priority support", "20 team members"] },
];

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-white">
      {/* Nav */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-md border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <span className="text-xl font-bold text-blue-700">FollowUp AI</span>
          <div className="flex items-center gap-4">
            <Link href="/sign-in" className="text-sm text-gray-600 hover:text-gray-900">Sign in</Link>
            <Link href="/sign-up" className="bg-blue-600 text-white text-sm px-4 py-2 rounded-lg hover:bg-blue-700 transition">Start Free</Link>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="pt-32 pb-20 px-4 max-w-7xl mx-auto">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
            <div className="inline-flex items-center gap-2 bg-blue-50 text-blue-700 text-sm font-medium px-3 py-1 rounded-full mb-6">
              <Zap className="w-3.5 h-3.5" /> For Coaching Institutes in India
            </div>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-gray-900 leading-tight mb-6">
              Stop Losing Students After Their{" "}
              <span className="gradient-text">First Enquiry.</span>
            </h1>
            <p className="text-lg text-gray-600 mb-8 leading-relaxed">
              FollowUp AI helps coaching institutes capture leads, automate follow-ups, generate personalized messages, and turn missed enquiries into enrollments.
            </p>
            <div className="flex flex-col sm:flex-row gap-3">
              <Link href="/sign-up" className="flex items-center justify-center gap-2 bg-blue-600 text-white px-6 py-3 rounded-xl font-semibold hover:bg-blue-700 transition text-base">
                Start Free <ArrowRight className="w-4 h-4" />
              </Link>
              <Link href="#demo" className="flex items-center justify-center gap-2 border border-gray-200 text-gray-700 px-6 py-3 rounded-xl font-semibold hover:bg-gray-50 transition text-base">
                Book a Demo
              </Link>
            </div>
            <div className="mt-8 flex flex-wrap items-center gap-4 text-sm text-gray-500">
              {["No credit card required", "Free plan forever", "Set up in 5 minutes"].map(t => (
                <span key={t} className="flex items-center gap-1.5"><CheckCircle2 className="w-4 h-4 text-green-500" />{t}</span>
              ))}
            </div>
          </motion.div>
          <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.7, delay: 0.2 }} className="h-[420px] rounded-2xl overflow-hidden shadow-2xl">
            <LeadFlowScene />
          </motion.div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20 bg-gray-50 px-4" id="features">
        <div className="max-w-7xl mx-auto">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">Everything a coaching institute needs</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">From first enquiry to final enrollment — FollowUp AI handles the whole journey.</p>
          </motion.div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {FEATURES.map((f, i) => (
              <motion.div key={f.title} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.05 }}
                className="bg-white rounded-xl p-6 shadow-sm hover:shadow-md transition border border-gray-100 card-hover">
                <div className="w-10 h-10 bg-blue-50 rounded-lg flex items-center justify-center mb-4">
                  <f.icon className="w-5 h-5 text-blue-600" />
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">{f.title}</h3>
                <p className="text-sm text-gray-600 leading-relaxed">{f.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="py-20 px-4" id="how-it-works">
        <div className="max-w-5xl mx-auto">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">How FollowUp AI works</h2>
            <p className="text-lg text-gray-600">Four simple steps to never lose a student again.</p>
          </motion.div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {STEPS.map((s, i) => (
              <motion.div key={s.n} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }} className="text-center">
                <div className="text-5xl font-black text-blue-100 mb-3">{s.n}</div>
                <h3 className="text-lg font-bold text-gray-900 mb-2">{s.title}</h3>
                <p className="text-sm text-gray-600 leading-relaxed">{s.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section className="py-20 bg-gray-50 px-4" id="pricing">
        <div className="max-w-5xl mx-auto">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">Simple, transparent pricing</h2>
            <p className="text-lg text-gray-600">Start free. Upgrade as you grow.</p>
          </motion.div>
          <div className="grid md:grid-cols-3 gap-8">
            {PLANS.map((p, i) => (
              <motion.div key={p.name} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }}
                className={`rounded-2xl p-8 border-2 ${p.highlight ? "border-blue-600 bg-blue-600 text-white shadow-xl" : "border-gray-200 bg-white"}`}>
                <div className={`text-sm font-semibold mb-2 ${p.highlight ? "text-blue-100" : "text-gray-500"}`}>{p.name}</div>
                <div className="flex items-end gap-1 mb-6">
                  <span className="text-4xl font-black">{p.price}</span>
                  <span className={`text-sm mb-1 ${p.highlight ? "text-blue-200" : "text-gray-500"}`}>{p.sub}</span>
                </div>
                <ul className="space-y-3 mb-8">
                  {p.features.map(f => (
                    <li key={f} className="flex items-center gap-2 text-sm">
                      <CheckCircle2 className={`w-4 h-4 flex-shrink-0 ${p.highlight ? "text-blue-200" : "text-green-500"}`} />
                      <span>{f}</span>
                    </li>
                  ))}
                </ul>
                <Link href="/sign-up" className={`block text-center py-3 rounded-xl font-semibold transition ${
                  p.highlight ? "bg-white text-blue-600 hover:bg-blue-50" : "bg-blue-600 text-white hover:bg-blue-700"
                }`}>Get Started</Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-gray-200 py-12 px-4">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="text-lg font-bold text-blue-700">FollowUp AI</div>
          <p className="text-sm text-gray-500">© {new Date().getFullYear()} FollowUp AI. All rights reserved.</p>
          <div className="flex gap-6 text-sm text-gray-500">
            <a href="#" className="hover:text-gray-900">Privacy</a>
            <a href="#" className="hover:text-gray-900">Terms</a>
            <a href="#" className="hover:text-gray-900">Contact</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
