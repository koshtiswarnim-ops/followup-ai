
import { auth, currentUser } from "@clerk/nextjs/server";
import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { sendWelcomeEmail } from "@/lib/email";
import { z } from "zod";

const schema = z.object({
  name: z.string().min(2).max(100),
  businessType: z.string().optional(),
  phone: z.string().optional(),
  email: z.string().email().optional().or(z.literal("")),
});

export async function POST(req: Request) {
  try {
    const { userId } = auth();
    if (!userId) return NextResponse.json({ success: false, error: { code: "UNAUTHORIZED", message: "Not authenticated" } }, { status: 401 });

    const clerkUser = await currentUser();
    if (!clerkUser) return NextResponse.json({ success: false, error: { code: "USER_NOT_FOUND", message: "User not found" } }, { status: 404 });

    const body = await req.json();
    const data = schema.parse(body);

    // Upsert user
    const user = await prisma.user.upsert({
      where: { clerkUserId: userId },
      update: {},
      create: { clerkUserId: userId, name: clerkUser.fullName || data.name, email: clerkUser.emailAddresses[0].emailAddress },
    });

    // Check if already has business
    const existingMember = await prisma.businessMember.findFirst({ where: { userId: user.id } });
    if (existingMember) return NextResponse.json({ success: true, data: { redirectTo: "/dashboard" } });

    // Create business
    const business = await prisma.business.create({
      data: {
        name: data.name, businessType: data.businessType || "Coaching Institute",
        phone: data.phone, email: data.email || clerkUser.emailAddresses[0].emailAddress,
        members: { create: { userId: user.id, role: "OWNER" } },
        subscription: { create: { plan: "FREE", status: "ACTIVE" } },
      },
    });

    // Send welcome email
    try { await sendWelcomeEmail(user.email, user.name, business.name); } catch {}

    return NextResponse.json({ success: true, data: { businessId: business.id, redirectTo: "/dashboard" } });
  } catch (err: any) {
    if (err.name === "ZodError") return NextResponse.json({ success: false, error: { code: "VALIDATION", message: err.errors[0]?.message } }, { status: 422 });
    console.error("Onboarding error:", err);
    return NextResponse.json({ success: false, error: { code: "SERVER_ERROR", message: "Internal server error" } }, { status: 500 });
  }
}
