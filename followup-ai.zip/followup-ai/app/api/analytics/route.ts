
import { NextResponse } from "next/server";
import { auth } from "@clerk/nextjs/server";
import { prisma } from "@/lib/prisma";

export async function GET(req: Request) {
  try {
    const { userId } = auth();
    if (!userId) return NextResponse.json({ success: false, error: { code: "UNAUTHORIZED", message: "Unauthorized" } }, { status: 401 });

    const user = await prisma.user.findUnique({ where: { clerkUserId: userId } });
    if (!user) return NextResponse.json({ success: false, error: { code: "NOT_FOUND", message: "User not found" } }, { status: 404 });

    const member = await prisma.businessMember.findFirst({ where: { userId: user.id } });
    if (!member) return NextResponse.json({ success: false, error: { code: "NOT_FOUND", message: "No business" } }, { status: 404 });

    const bid = member.businessId;
    const now = new Date();
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
    const weekStart = new Date(now); weekStart.setDate(now.getDate() - 6);

    const [totalLeads, newLeads, converted, followUpsDue, byStatus, bySource, dailyLeads, activities] = await Promise.all([
      prisma.lead.count({ where: { businessId: bid } }),
      prisma.lead.count({ where: { businessId: bid, createdAt: { gte: monthStart } } }),
      prisma.lead.count({ where: { businessId: bid, status: "CONVERTED" } }),
      prisma.followUp.count({ where: { businessId: bid, status: "PENDING", scheduledAt: { lte: now } } }),
      prisma.lead.groupBy({ by: ["status"], where: { businessId: bid }, _count: true }),
      prisma.lead.groupBy({ by: ["source"], where: { businessId: bid }, _count: true }),
      prisma.lead.groupBy({ by: ["createdAt"], where: { businessId: bid, createdAt: { gte: weekStart } }, _count: true, orderBy: { createdAt: "asc" } }),
      prisma.activity.findMany({ where: { businessId: bid }, orderBy: { createdAt: "desc" }, take: 20, include: { user: { select: { name: true } }, lead: { select: { name: true } } } }),
    ]);

    const conversionRate = totalLeads > 0 ? Math.round((converted / totalLeads) * 100) : 0;

    return NextResponse.json({
      success: true,
      data: {
        stats: { totalLeads, newLeads, converted, followUpsDue, conversionRate },
        byStatus: byStatus.map(s => ({ name: s.status, value: s._count })),
        bySource: bySource.map(s => ({ name: s.source, value: s._count })),
        dailyLeads, activities,
      },
    });
  } catch (err: any) {
    return NextResponse.json({ success: false, error: { code: "SERVER_ERROR", message: err.message } }, { status: 500 });
  }
}
