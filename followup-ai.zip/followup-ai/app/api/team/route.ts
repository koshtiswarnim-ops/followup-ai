
import { NextResponse } from "next/server";
import { auth } from "@clerk/nextjs/server";
import { prisma } from "@/lib/prisma";

async function getCtx(clerkId: string) {
  const user = await prisma.user.findUnique({ where: { clerkUserId: clerkId } });
  if (!user) throw new Error("Not found");
  const member = await prisma.businessMember.findFirst({ where: { userId: user.id } });
  if (!member) throw new Error("No business");
  return { user, member };
}

export async function GET() {
  const { userId } = auth();
  if (!userId) return NextResponse.json({ success: false, error: { code: "UNAUTHORIZED", message: "Unauthorized" } }, { status: 401 });
  const { member } = await getCtx(userId);
  const members = await prisma.businessMember.findMany({
    where: { businessId: member.businessId },
    include: { user: { select: { id: true, name: true, email: true, createdAt: true } } },
    orderBy: { createdAt: "asc" },
  });
  return NextResponse.json({ success: true, data: members });
}
