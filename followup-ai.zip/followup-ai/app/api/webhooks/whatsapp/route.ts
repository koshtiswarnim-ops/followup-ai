
import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { verifyWhatsAppWebhook, parseWhatsAppWebhookPayload } from "@/lib/whatsapp";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const mode = url.searchParams.get("hub.mode");
  const token = url.searchParams.get("hub.verify_token");
  const challenge = url.searchParams.get("hub.challenge");
  if (mode === "subscribe" && token && challenge) {
    const verifyToken = process.env.WHATSAPP_WEBHOOK_VERIFY_TOKEN || "";
    const result = verifyWhatsAppWebhook(token, challenge, verifyToken);
    if (result) return new Response(result, { status: 200 });
  }
  return new Response("Forbidden", { status: 403 });
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const messages = parseWhatsAppWebhookPayload(body);
    for (const msg of messages) {
      const cleanPhone = msg.from.replace(/^91/, "");
      const lead = await prisma.lead.findFirst({
        where: { phone: { in: [msg.from, cleanPhone, `+91${cleanPhone}`] } },
      });
      if (lead) {
        await prisma.activity.create({
          data: {
            businessId: lead.businessId, leadId: lead.id,
            type: "MESSAGE_RECEIVED",
            description: `WhatsApp message received: ${msg.text.slice(0, 100)}`,
            metadata: { messageId: msg.messageId, text: msg.text },
          },
        });
        if (lead.assignedTo) {
          await prisma.notification.create({
            data: {
              businessId: lead.businessId, userId: lead.assignedTo,
              type: "MESSAGE_RECEIVED",
              title: `WhatsApp from ${lead.name}`,
              message: msg.text.slice(0, 200),
            },
          });
        }
      }
    }
    return NextResponse.json({ received: true });
  } catch (err) {
    console.error("WhatsApp webhook error:", err);
    return NextResponse.json({ error: "Processing failed" }, { status: 500 });
  }
}
