
import { NextResponse } from "next/server";
import crypto from "crypto";
import { prisma } from "@/lib/prisma";
import { sendSubscriptionConfirmationEmail, sendPaymentFailedEmail } from "@/lib/email";

export async function POST(req: Request) {
  try {
    const body = await req.text();
    const signature = req.headers.get("x-razorpay-signature");
    const secret = process.env.RAZORPAY_WEBHOOK_SECRET!;

    if (!signature) return NextResponse.json({ error: "Missing signature" }, { status: 400 });

    // Verify webhook signature
    const expected = crypto.createHmac("sha256", secret).update(body).digest("hex");
    if (!crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(signature))) {
      return NextResponse.json({ error: "Invalid signature" }, { status: 401 });
    }

    const event = JSON.parse(body);
    const { event: eventName, payload } = event;

    switch (eventName) {
      case "subscription.activated": {
        const sub = payload.subscription.entity;
        await prisma.subscription.updateMany({
          where: { razorpaySubscriptionId: sub.id },
          data: { status: "ACTIVE", currentPeriodStart: new Date(sub.current_start * 1000), currentPeriodEnd: new Date(sub.current_end * 1000) },
        });
        break;
      }
      case "subscription.charged": {
        const sub = payload.subscription.entity;
        const dbSub = await prisma.subscription.findFirst({ where: { razorpaySubscriptionId: sub.id }, include: { business: { include: { members: { include: { user: true }, where: { role: "OWNER" } } } } } });
        if (dbSub) {
          await prisma.subscription.update({ where: { id: dbSub.id }, data: { status: "ACTIVE", leadsUsedThisMonth: 0, currentPeriodStart: new Date(sub.current_start * 1000), currentPeriodEnd: new Date(sub.current_end * 1000) } });
          const owner = dbSub.business.members[0]?.user;
          if (owner) { try { await sendSubscriptionConfirmationEmail(owner.email, owner.name, dbSub.plan); } catch {} }
        }
        break;
      }
      case "subscription.cancelled": {
        const sub = payload.subscription.entity;
        await prisma.subscription.updateMany({ where: { razorpaySubscriptionId: sub.id }, data: { status: "CANCELLED" } });
        break;
      }
      case "payment.failed": {
        const payment = payload.payment.entity;
        const sub = await prisma.subscription.findFirst({ where: { razorpayCustomerId: payment.customer_id }, include: { business: { include: { members: { include: { user: true }, where: { role: "OWNER" } } } } } });
        if (sub) {
          await prisma.subscription.update({ where: { id: sub.id }, data: { status: "PAST_DUE" } });
          const owner = sub.business.members[0]?.user;
          if (owner) { try { await sendPaymentFailedEmail(owner.email, owner.name); } catch {} }
        }
        break;
      }
    }

    return NextResponse.json({ received: true });
  } catch (err: any) {
    console.error("Razorpay webhook error:", err);
    return NextResponse.json({ error: "Webhook processing failed" }, { status: 500 });
  }
}
