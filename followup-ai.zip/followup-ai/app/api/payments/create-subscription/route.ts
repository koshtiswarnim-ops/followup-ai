
import { NextResponse } from "next/server";
import { auth } from "@clerk/nextjs/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";

const PLAN_IDS: Record<string, string> = {
  GROWTH: process.env.RAZORPAY_GROWTH_PLAN_ID || "plan_growth",
  PRO: process.env.RAZORPAY_PRO_PLAN_ID || "plan_pro",
};

const schema = z.object({ plan: z.enum(["GROWTH","PRO"]) });

export async function POST(req: Request) {
  try {
    const { userId } = auth();
    if (!userId) return NextResponse.json({ success: false, error: { code: "UNAUTHORIZED", message: "Unauthorized" } }, { status: 401 });
    const user = await prisma.user.findUnique({ where: { clerkUserId: userId } });
    if (!user) return NextResponse.json({ success: false, error: { code: "NOT_FOUND", message: "User not found" } }, { status: 404 });
    const member = await prisma.businessMember.findFirst({ where: { userId: user.id, role: { in: ["OWNER"] } }, include: { business: { include: { subscription: true } } } });
    if (!member) return NextResponse.json({ success: false, error: { code: "FORBIDDEN", message: "Only owners can manage billing" } }, { status: 403 });

    const body = await req.json();
    const { plan } = schema.parse(body);

    if (process.env.DEMO_MODE === "true") {
      return NextResponse.json({
        success: true,
        data: {
          demo: true,
          message: "Demo mode: Subscription simulation. In production, Razorpay subscription would be created here.",
          planId: PLAN_IDS[plan],
        },
      });
    }

    const Razorpay = (await import("razorpay")).default;
    const razorpay = new Razorpay({ key_id: process.env.RAZORPAY_KEY_ID!, key_secret: process.env.RAZORPAY_KEY_SECRET! });

    const subscription = await razorpay.subscriptions.create({
      plan_id: PLAN_IDS[plan], customer_notify: 1, total_count: 12,
      notes: { businessId: member.businessId, userId: user.id },
    });

    await prisma.subscription.update({
      where: { businessId: member.businessId },
      data: { razorpaySubscriptionId: subscription.id, plan, status: "TRIALING" },
    });

    return NextResponse.json({ success: true, data: { subscriptionId: subscription.id, plan } });
  } catch (err: any) {
    return NextResponse.json({ success: false, error: { code: "SERVER_ERROR", message: err.message } }, { status: 500 });
  }
}
