
import { NextResponse } from "next/server";
import { auth } from "@clerk/nextjs/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";

const schema = z.object({
  name: z.string().min(1).max(100),
  content: z.string().min(1),
  channel: z.enum(["WHATSAPP","EMAIL","SMS","MANUAL"]).optional(),
});

async function getCtx(clerkId: string) {
  const user = await prisma.user.findUnique({ where: { clerkUserId: clerkId } });
  if (!user) throw new Error("Not found");
  const member = await prisma.businessMember.findFirst({ where: { userId: user.id } });
  if (!member) throw new Error("No business");
  return { user, member };
}

export async function GET() {
  const { userId } = auth();
  if (!userId) return NextResponse.json({ success: false, error: { code: "UNAUTHORIZED", message: "Unauthorized" } }, { status: 401 });
  const { member } = await getCtx(userId);
  const templates = await prisma.messageTemplate.findMany({ where: { businessId: member.businessId, isActive: true }, orderBy: { createdAt: "desc" } });
  return NextResponse.json({ success: true, data: templates });
}

export async function POST(req: Request) {
  const { userId } = auth();
  if (!userId) return NextResponse.json({ success: false, error: { code: "UNAUTHORIZED", message: "Unauthorized" } }, { status: 401 });
  const { member } = await getCtx(userId);
  const body = await req.json();
  const data = schema.parse(body);
  // Extract variables like {{student_name}}
  const vars = (data.content.match(/\{\{(\w+)\}\}/g) || []).map((v: string) => v.slice(2,-2));
  const template = await prisma.messageTemplate.create({ data: { businessId: member.businessId, name: data.name, content: data.content, channel: data.channel || "WHATSAPP", variables: vars } });
  return NextResponse.json({ success: true, data: template }, { status: 201 });
}
