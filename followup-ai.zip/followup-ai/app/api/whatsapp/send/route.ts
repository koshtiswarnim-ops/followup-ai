
import { NextResponse } from "next/server";
import { auth } from "@clerk/nextjs/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { sendWhatsAppMessage } from "@/lib/whatsapp";

const schema = z.object({ leadId: z.string(), message: z.string().min(1), followUpId: z.string().optional() });

export async function POST(req: Request) {
  try {
    const { userId } = auth();
    if (!userId) return NextResponse.json({ success: false, error: { code: "UNAUTHORIZED", message: "Unauthorized" } }, { status: 401 });
    const user = await prisma.user.findUnique({ where: { clerkUserId: userId } });
    if (!user) return NextResponse.json({ success: false, error: { code: "NOT_FOUND", message: "Not found" } }, { status: 404 });
    const member = await prisma.businessMember.findFirst({ where: { userId: user.id } });
    if (!member) return NextResponse.json({ success: false, error: { code: "NOT_FOUND", message: "Business not found" } }, { status: 404 });

    const body = await req.json();
    const data = schema.parse(body);
    const lead = await prisma.lead.findFirst({ where: { id: data.leadId, businessId: member.businessId } });
    if (!lead) return NextResponse.json({ success: false, error: { code: "NOT_FOUND", message: "Lead not found" } }, { status: 404 });
    if (!lead.phone) return NextResponse.json({ success: false, error: { code: "VALIDATION", message: "Lead has no phone number" } }, { status: 422 });

    const waAccount = await prisma.whatsAppAccount.findUnique({ where: { businessId: member.businessId } });

    const result = await sendWhatsAppMessage({
      to: lead.phone, message: data.message,
      phoneNumberId: waAccount?.phoneNumberId || undefined,
    });

    if (result.success) {
      await prisma.activity.create({
        data: {
          businessId: member.businessId, leadId: lead.id, userId: user.id,
          type: "MESSAGE_SENT",
          description: `WhatsApp message sent${result.demo ? " (Demo)" : ""}`,
          metadata: { messageId: result.messageId, channel: "WHATSAPP", demo: result.demo },
        },
      });
      if (data.followUpId) {
        await prisma.followUp.update({ where: { id: data.followUpId }, data: { status: "SENT", sentAt: new Date() } });
      }
      await prisma.lead.update({ where: { id: lead.id }, data: { lastContact: new Date(), status: "CONTACTED" } });
    }

    return NextResponse.json({ success: result.success, data: { messageId: result.messageId, demo: result.demo }, error: result.error ? { code: "WA_ERROR", message: result.error } : undefined });
  } catch (err: any) {
    return NextResponse.json({ success: false, error: { code: "SERVER_ERROR", message: err.message } }, { status: 500 });
  }
}
