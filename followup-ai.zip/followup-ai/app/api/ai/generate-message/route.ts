
import { NextResponse } from "next/server";
import { auth } from "@clerk/nextjs/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { generateFollowUpMessage } from "@/lib/openai";
import { getPlanLimits } from "@/lib/utils";

const schema = z.object({
  leadId: z.string().optional(),
  situation: z.string(),
  tone: z.string(),
  channel: z.string(),
});

export async function POST(req: Request) {
  try {
    const { userId } = auth();
    if (!userId) return NextResponse.json({ success: false, error: { code: "UNAUTHORIZED", message: "Unauthorized" } }, { status: 401 });

    const user = await prisma.user.findUnique({ where: { clerkUserId: userId } });
    if (!user) return NextResponse.json({ success: false, error: { code: "NOT_FOUND", message: "User not found" } }, { status: 404 });

    const member = await prisma.businessMember.findFirst({
      where: { userId: user.id },
      include: { business: { include: { subscription: true } } },
    });
    if (!member) return NextResponse.json({ success: false, error: { code: "NOT_FOUND", message: "Business not found" } }, { status: 404 });

    // Rate limit by plan
    const sub = member.business.subscription;
    if (sub) {
      const limits = getPlanLimits(sub.plan);
      const monthStart = new Date(); monthStart.setDate(1); monthStart.setHours(0,0,0,0);
      const aiCount = await prisma.aiGeneration.count({
        where: { businessId: member.businessId, createdAt: { gte: monthStart } },
      });
      if (aiCount >= limits.aiMessages) {
        return NextResponse.json({ success: false, error: { code: "RATE_LIMIT", message: `AI message limit reached for ${sub.plan} plan.` } }, { status: 429 });
      }
    }

    const body = await req.json();
    const data = schema.parse(body);

    let lead = null;
    if (data.leadId) {
      lead = await prisma.lead.findFirst({ where: { id: data.leadId, businessId: member.businessId } });
    }

    const message = await generateFollowUpMessage({
      studentName: lead?.name || "Student",
      course: lead?.course || "the course",
      situation: data.situation,
      tone: data.tone,
      channel: data.channel,
      businessName: member.business.name,
      leadStatus: lead?.status,
      lastContact: lead?.lastContact?.toLocaleDateString("en-IN"),
    });

    // Log generation
    const generation = await prisma.aiGeneration.create({
      data: {
        businessId: member.businessId, leadId: data.leadId || null,
        userId: user.id, prompt: JSON.stringify(data),
        generatedText: message, situation: data.situation,
        tone: data.tone, channel: data.channel,
      },
    });

    return NextResponse.json({ success: true, data: { message, generationId: generation.id } });
  } catch (err: any) {
    if (err.name === "ZodError") return NextResponse.json({ success: false, error: { code: "VALIDATION", message: err.errors[0]?.message } }, { status: 422 });
    return NextResponse.json({ success: false, error: { code: "SERVER_ERROR", message: err.message } }, { status: 500 });
  }
}
