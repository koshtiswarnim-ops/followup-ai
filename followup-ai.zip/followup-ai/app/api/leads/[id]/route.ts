
import { NextResponse } from "next/server";
import { auth } from "@clerk/nextjs/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { getLeadById, updateLead, deleteLead } from "@/services/leadService";

const updateSchema = z.object({
  name: z.string().min(1).max(100).optional(),
  phone: z.string().optional(),
  email: z.string().email().optional().or(z.literal("")),
  course: z.string().optional(),
  source: z.enum(["WEBSITE","WHATSAPP","INSTAGRAM","FACEBOOK","REFERRAL","WALK_IN","OTHER"]).optional(),
  status: z.enum(["NEW","CONTACTED","INTERESTED","FOLLOW_UP","CONVERTED","LOST"]).optional(),
  notes: z.string().optional(),
  assignedTo: z.string().nullable().optional(),
});

async function getCtx(clerkUserId: string) {
  const user = await prisma.user.findUnique({ where: { clerkUserId } });
  if (!user) throw new Error("User not found");
  const member = await prisma.businessMember.findFirst({ where: { userId: user.id } });
  if (!member) throw new Error("No business");
  return { user, member };
}

export async function GET(_: Request, { params }: { params: { id: string } }) {
  try {
    const { userId } = auth();
    if (!userId) return NextResponse.json({ success: false, error: { code: "UNAUTHORIZED", message: "Unauthorized" } }, { status: 401 });
    const { member } = await getCtx(userId);
    const lead = await getLeadById(params.id, member.businessId);
    if (!lead) return NextResponse.json({ success: false, error: { code: "NOT_FOUND", message: "Lead not found" } }, { status: 404 });
    return NextResponse.json({ success: true, data: lead });
  } catch (err: any) {
    return NextResponse.json({ success: false, error: { code: "SERVER_ERROR", message: err.message } }, { status: 500 });
  }
}

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  try {
    const { userId } = auth();
    if (!userId) return NextResponse.json({ success: false, error: { code: "UNAUTHORIZED", message: "Unauthorized" } }, { status: 401 });
    const { user, member } = await getCtx(userId);
    const body = await req.json();
    const data = updateSchema.parse(body);
    const lead = await updateLead(params.id, member.businessId, user.id, data);
    return NextResponse.json({ success: true, data: lead });
  } catch (err: any) {
    if (err.name === "ZodError") return NextResponse.json({ success: false, error: { code: "VALIDATION", message: err.errors[0]?.message } }, { status: 422 });
    return NextResponse.json({ success: false, error: { code: "SERVER_ERROR", message: err.message } }, { status: 500 });
  }
}

export async function DELETE(_: Request, { params }: { params: { id: string } }) {
  try {
    const { userId } = auth();
    if (!userId) return NextResponse.json({ success: false, error: { code: "UNAUTHORIZED", message: "Unauthorized" } }, { status: 401 });
    const { user, member } = await getCtx(userId);
    if (member.role === "STAFF") return NextResponse.json({ success: false, error: { code: "FORBIDDEN", message: "Insufficient permissions" } }, { status: 403 });
    await deleteLead(params.id, member.businessId, user.id);
    return NextResponse.json({ success: true, data: { deleted: true } });
  } catch (err: any) {
    return NextResponse.json({ success: false, error: { code: "SERVER_ERROR", message: err.message } }, { status: 500 });
  }
}
