
import { NextResponse } from "next/server";
import { auth } from "@clerk/nextjs/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { createLead, getLeads } from "@/services/leadService";
import { getPlanLimits } from "@/lib/utils";

const createSchema = z.object({
  name: z.string().min(1).max(100),
  phone: z.string().optional(),
  email: z.string().email().optional().or(z.literal("")),
  course: z.string().optional(),
  source: z.enum(["WEBSITE","WHATSAPP","INSTAGRAM","FACEBOOK","REFERRAL","WALK_IN","OTHER"]).optional(),
  notes: z.string().optional(),
  assignedTo: z.string().optional(),
});

async function getBusinessContext(clerkUserId: string) {
  const user = await prisma.user.findUnique({ where: { clerkUserId } });
  if (!user) throw new Error("User not found");
  const member = await prisma.businessMember.findFirst({
    where: { userId: user.id },
    include: { business: { include: { subscription: true } } },
  });
  if (!member) throw new Error("No business found");
  return { user, member, business: member.business };
}

export async function GET(req: Request) {
  try {
    const { userId } = auth();
    if (!userId) return NextResponse.json({ success: false, error: { code: "UNAUTHORIZED", message: "Unauthorized" } }, { status: 401 });
    const { user, member } = await getBusinessContext(userId);
    const url = new URL(req.url);
    const result = await getLeads(member.businessId, {
      page: Number(url.searchParams.get("page")) || 1,
      limit: Number(url.searchParams.get("limit")) || 20,
      status: url.searchParams.get("status") || undefined,
      source: url.searchParams.get("source") || undefined,
      search: url.searchParams.get("search") || undefined,
      assignedTo: url.searchParams.get("assignedTo") || undefined,
    });
    return NextResponse.json({ success: true, data: result });
  } catch (err: any) {
    return NextResponse.json({ success: false, error: { code: "SERVER_ERROR", message: err.message } }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const { userId } = auth();
    if (!userId) return NextResponse.json({ success: false, error: { code: "UNAUTHORIZED", message: "Unauthorized" } }, { status: 401 });
    const { user, member, business } = await getBusinessContext(userId);

    // Plan limit check
    const sub = business.subscription;
    if (sub) {
      const limits = getPlanLimits(sub.plan);
      if (sub.leadsUsedThisMonth >= limits.leads) {
        return NextResponse.json({ success: false, error: { code: "PLAN_LIMIT", message: `Lead limit reached for ${sub.plan} plan. Please upgrade.` } }, { status: 403 });
      }
    }

    const body = await req.json();
    const data = createSchema.parse(body);
    const lead = await createLead({ businessId: member.businessId, userId: user.id, ...data });
    return NextResponse.json({ success: true, data: lead }, { status: 201 });
  } catch (err: any) {
    if (err.name === "ZodError") return NextResponse.json({ success: false, error: { code: "VALIDATION", message: err.errors[0]?.message } }, { status: 422 });
    return NextResponse.json({ success: false, error: { code: "SERVER_ERROR", message: err.message } }, { status: 500 });
  }
}
