
import { NextResponse } from "next/server";
import { auth } from "@clerk/nextjs/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { createFollowUp, createFollowUpSequence } from "@/services/followUpService";

const schema = z.object({
  leadId: z.string(),
  scheduledAt: z.string().datetime(),
  message: z.string().optional(),
  channel: z.enum(["WHATSAPP","EMAIL","SMS","MANUAL"]).optional(),
  assignedTo: z.string().optional(),
  notes: z.string().optional(),
  sequence: z.boolean().optional(),
  intervals: z.array(z.number()).optional(),
});

async function getCtx(clerkUserId: string) {
  const user = await prisma.user.findUnique({ where: { clerkUserId } });
  if (!user) throw new Error("User not found");
  const member = await prisma.businessMember.findFirst({ where: { userId: user.id } });
  if (!member) throw new Error("No business");
  return { user, member };
}

export async function GET(req: Request) {
  try {
    const { userId } = auth();
    if (!userId) return NextResponse.json({ success: false, error: { code: "UNAUTHORIZED", message: "Unauthorized" } }, { status: 401 });
    const { member } = await getCtx(userId);
    const url = new URL(req.url);
    const status = url.searchParams.get("status") || undefined;
    const leadId = url.searchParams.get("leadId") || undefined;
    const followUps = await prisma.followUp.findMany({
      where: { businessId: member.businessId, ...(status ? { status: status as any } : {}), ...(leadId ? { leadId } : {}) },
      include: { lead: { select: { id: true, name: true, phone: true, course: true } }, assignedUser: { select: { id: true, name: true } } },
      orderBy: { scheduledAt: "asc" }, take: 100,
    });
    return NextResponse.json({ success: true, data: followUps });
  } catch (err: any) {
    return NextResponse.json({ success: false, error: { code: "SERVER_ERROR", message: err.message } }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const { userId } = auth();
    if (!userId) return NextResponse.json({ success: false, error: { code: "UNAUTHORIZED", message: "Unauthorized" } }, { status: 401 });
    const { user, member } = await getCtx(userId);
    const body = await req.json();
    const data = schema.parse(body);
    if (data.sequence) {
      const fus = await createFollowUpSequence(member.businessId, data.leadId, user.id, data.intervals || [1,3,7,14]);
      return NextResponse.json({ success: true, data: fus }, { status: 201 });
    }
    const fu = await createFollowUp({ businessId: member.businessId, userId: user.id, leadId: data.leadId, scheduledAt: new Date(data.scheduledAt), message: data.message, channel: data.channel, assignedTo: data.assignedTo, notes: data.notes });
    return NextResponse.json({ success: true, data: fu }, { status: 201 });
  } catch (err: any) {
    if (err.name === "ZodError") return NextResponse.json({ success: false, error: { code: "VALIDATION", message: err.errors[0]?.message } }, { status: 422 });
    return NextResponse.json({ success: false, error: { code: "SERVER_ERROR", message: err.message } }, { status: 500 });
  }
}
