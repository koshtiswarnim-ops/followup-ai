
import { PrismaClient, LeadSource, LeadStatus } from "@prisma/client";
const prisma = new PrismaClient();

async function main() {
  console.log("Seeding database...");

  // Demo user
  const user = await prisma.user.upsert({
    where: { email: "demo@followupai.in" },
    update: {},
    create: { clerkUserId: "demo_clerk_user_id", name: "Rajesh Kumar", email: "demo@followupai.in" },
  });

  // Demo business
  const business = await prisma.business.upsert({
    where: { id: "demo_business_id" },
    update: {},
    create: {
      id: "demo_business_id",
      name: "Sharma Coaching Institute",
      businessType: "Coaching Institute",
      phone: "+91 98765 43210",
      email: "info@sharmacoaching.in",
      address: "123, Lajpat Nagar, New Delhi - 110024",
      members: { create: { userId: user.id, role: "OWNER" } },
      subscription: { create: { plan: "GROWTH", status: "ACTIVE" } },
    },
  });

  const LEADS = [
    { name: "Aarav Sharma", phone: "+91 98765 00001", email: "aarav@example.com", course: "JEE Main 2027", source: "WEBSITE" as LeadSource, status: "INTERESTED" as LeadStatus },
    { name: "Priya Patel", phone: "+91 98765 00002", email: "priya@example.com", course: "NEET 2027", source: "INSTAGRAM" as LeadSource, status: "FOLLOW_UP" as LeadStatus },
    { name: "Rohan Mehta", phone: "+91 98765 00003", email: "rohan@example.com", course: "JEE Advanced", source: "REFERRAL" as LeadSource, status: "CONTACTED" as LeadStatus },
    { name: "Ananya Singh", phone: "+91 98765 00004", email: "ananya@example.com", course: "Foundation", source: "WALK_IN" as LeadSource, status: "CONVERTED" as LeadStatus },
    { name: "Rahul Verma", phone: "+91 98765 00005", email: "rahul@example.com", course: "Class 12", source: "WHATSAPP" as LeadSource, status: "NEW" as LeadStatus },
  ];

  for (const lead of LEADS) {
    const l = await prisma.lead.create({
      data: { businessId: business.id, ...lead, assignedTo: user.id, lastContact: new Date() },
    });
    await prisma.followUp.create({
      data: {
        businessId: business.id, leadId: l.id, assignedTo: user.id,
        scheduledAt: new Date(Date.now() + Math.random() * 7 * 86400000),
        channel: "WHATSAPP", status: "PENDING",
        message: `Hi ${lead.name}! Following up on your enquiry for ${lead.course}. Are you still interested?`,
      },
    });
    await prisma.activity.create({
      data: { businessId: business.id, leadId: l.id, userId: user.id, type: "LEAD_CREATED", description: `Lead created for ${lead.name}` },
    });
  }

  // Message templates
  const templates = [
    { name: "First Follow-up", content: "Hi {{student_name}}! Thank you for enquiring about {{course}} at {{institute_name}}. Our counsellor {{counsellor_name}} will reach out shortly. Please feel free to call us anytime!", channel: "WHATSAPP" },
    { name: "Fee Enquiry", content: "Hi {{student_name}}, regarding the fee structure for {{course}} at {{institute_name}} – we have flexible EMI options starting at ₹2,500/month. Shall I share the complete fee details?", channel: "WHATSAPP" },
    { name: "Admission Reminder", content: "Hi {{student_name}}! Seats for {{course}} at {{institute_name}} are filling up fast. Last date to enroll is approaching. Don't miss this opportunity!", channel: "WHATSAPP" },
  ];

  for (const t of templates) {
    await prisma.messageTemplate.create({
      data: { businessId: business.id, ...t as any, variables: ["student_name","course","institute_name","counsellor_name"] },
    });
  }

  console.log("✅ Seed complete!");
  console.log(`Business: ${business.name}`);
  console.log(`Leads: ${LEADS.length} created`);
}

main().catch(console.error).finally(() => prisma.$disconnect());
