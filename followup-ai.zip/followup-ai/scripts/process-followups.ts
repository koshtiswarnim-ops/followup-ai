
import { processOverdueFollowUps } from "../services/followUpService";

async function main() {
  console.log("Processing overdue follow-ups...");
  const result = await processOverdueFollowUps();
  console.log(`Processed: ${result.processed}`);
  process.exit(0);
}

main().catch(err => { console.error(err); process.exit(1); });
